name = 'nextbike_api'
